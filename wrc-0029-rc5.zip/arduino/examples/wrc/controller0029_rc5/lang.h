/*
+---------------------------------------------------------------------------
|   > Copyright (c) 2013
|   > Bourgeois Jerome
+---------------------------------------------------------------------------
|   > Controller LANGUAGE
|   > Module written by Bourgeois Jerome
|   > mail.bjerome@gmail.com
----------------------------------------------
|   > Date started: Aug 2, 2012
|   > Release updated: Jan 28, 2013 - 10:18 PM
+---------------------------------------------
|   > Module Version Number: 0.0.0.1
+---------------------------------------------
|   > Web Reef Controller
+--------------------------------------------------------------------------
*/

//FR
String lang_d1        = "Lundi", lang_d2 = "Mardi", lang_d3 = "Mercredi", lang_d4 = "Jeudi", lang_d5 = "Vendredi", lang_d6 = "Samedi", lang_d7 = "Dimanche";
String lang_m1        = "Janvier", lang_m2 = "Fevrier", lang_m3 = "Mars", lang_m4 = "Avril", lang_m5 = "Mai", lang_m6 = "Juin", lang_m7 = "Juillet", lang_m8 = "Aout", lang_m9 = "Septembre", lang_m10 = "Octobre", lang_m11= "Novembre", lang_m12 = "Decembre";

//US
//String lang_d1      = "Monday", lang_d2 = "Tuesday", lang_d3 = "Wednesday", lang_d4 = "Thursday", lang_d5 = "Friday", lang_d6 = "Saturday", lang_d7 = "Sunday";
//String lang_m1      = "January", lang_m2 = "February", lang_m3 = "March", lang_m4 = "April", lang_m5 = "May", lang_m6 = "June", lang_m7 = "July", lang_m8 = "August" , lang_m9 = "September", lang_m10 = "October", lang_m11 = "November", lang_m12 = "December";
